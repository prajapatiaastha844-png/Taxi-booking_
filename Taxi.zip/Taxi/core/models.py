from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.contrib.auth.hashers import check_password, make_password
from django.db import models


class AdminUser(AbstractUser):
    class Meta:
        db_table = "core_admin"


class UserManager(BaseUserManager):
    def create_user(self, name, email, mobile, password):
        user = self.model(
            name=name,
            email=self.normalize_email(email),
            mobile=mobile,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user


class User(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    mobile = models.CharField(max_length=20)
    password = models.CharField(max_length=128)

    objects = UserManager()

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.name


class Driver(models.Model):
    name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    license_number = models.CharField(max_length=50, unique=True)
    mobile = models.CharField(max_length=20)
    password = models.CharField(max_length=128)

    def set_password(self, raw_password):
        self.password = make_password(raw_password)

    def check_password(self, raw_password):
        return check_password(raw_password, self.password)

    def __str__(self):
        return self.name
