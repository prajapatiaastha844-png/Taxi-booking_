from django import forms
from django.core.exceptions import ValidationError
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.password_validation import validate_password

from .models import AdminUser, User


class AdminRegistrationForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta(UserCreationForm.Meta):
        model = AdminUser
        fields = ("username", "email")


class CustomerUserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("name", "email", "mobile")
        widgets = {
            "name": forms.TextInput(attrs={"autocomplete": "name"}),
            "email": forms.EmailInput(attrs={"autocomplete": "email"}),
            "mobile": forms.TextInput(
                attrs={"autocomplete": "tel", "inputmode": "tel"}
            ),
        }


class AdminPasswordResetRequestForm(forms.Form):
    email = forms.EmailField()


class AdminPasswordResetOTPForm(forms.Form):
    otp = forms.RegexField(
        regex=r"^\d{6}$",
        max_length=6,
        min_length=6,
        widget=forms.TextInput(
            attrs={"autocomplete": "one-time-code", "inputmode": "numeric"}
        ),
    )


class AdminSetNewPasswordForm(forms.Form):
    new_password1 = forms.CharField(
        label="New password",
        widget=forms.PasswordInput,
    )
    new_password2 = forms.CharField(
        label="Confirm new password",
        widget=forms.PasswordInput,
    )

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        self.user = user

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get("new_password1")
        password2 = cleaned_data.get("new_password2")

        if password1 and password2:
            if password1 != password2:
                self.add_error("new_password2", "The passwords do not match.")
            else:
                try:
                    validate_password(password1, self.user)
                except ValidationError as error:
                    self.add_error("new_password1", error)

        return cleaned_data
